"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";

export default function POS() {
  const [products, setProducts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [customer, setCustomer] = useState("");
  const [cashRef, setCashRef] = useState("");
  const [pickup, setPickup] = useState("");
  const [pickupPhone, setPickupPhone] = useState("");
  const [pay, setPay] = useState("Cash");
  const [paid, setPaid] = useState("");
  const [search, setSearch] = useState("");
  const [done, setDone] = useState<any>(null);
  const [warranty, setWarranty] = useState("0");
  const [imei, setImei] = useState("");

  const load = () =>
    Promise.all([
      fetch("/api/data?collection=products").then((r) => r.json()),
      fetch("/api/data?collection=customers").then((r) => r.json()),
    ]).then(([p, c]) => {
      setProducts(p);
      setCustomers(c);
    });

  useEffect(() => { void load(); }, []);

  const total = useMemo(
    () => items.reduce((sum, item) => sum + Number(item.price) * Number(item.qty), 0),
    [items]
  );
  const remaining = Math.max(0, total - Number(paid || 0));

  function add(product: any) {
    setItems((current) => {
      const found = current.find((item) => item.productId === product._id);
      if (found) {
        return current.map((item) =>
          item.productId === product._id
            ? { ...item, qty: Math.min(item.qty + 1, Number(product.stock || 0)) }
            : item
        );
      }
      return [
        ...current,
        {
          productId: product._id,
          name: product.name,
          model: product.model,
          price: Number(product.price || 0),
          costPrice: Number(product.costPrice || 0),
          qty: 1,
        },
      ];
    });
  }

  async function complete() {
    if (!items.length) return alert("Item select karein");
    if (!customer && !cashRef) {
      return alert("Saved Customer select karein ya Cash Sale Ref likhein");
    }

    const invoiceNo = "INV-" + Date.now();
    const sale = {
      invoiceNo,
      saleType: customer ? "customer" : "cash",
      customerId: customer || null,
      cashRef: cashRef || null,
      pickupBy: pickup || null,
      pickupPhone: pickupPhone || null,
      items,
      total,
      paid: Number(paid || 0),
      remaining,
      paymentMethod: pay,
      warrantyDays: Number(warranty || 0),
      warrantyStart: new Date().toISOString(),
      imei: imei || null,
      status: remaining > 0 ? "credit" : "paid",
      createdAt: new Date().toISOString(),
    };

    const response = await fetch("/api/data", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ collection: "sales", ...sale }),
    });
    const saved = await response.json();
    if (!response.ok) return alert(saved.error || "Sale failed");

    for (const item of items) {
      await fetch("/api/data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          collection: "stockMovements",
          type: "OUT",
          productId: item.productId,
          qty: item.qty,
          ref: invoiceNo,
          reason: "Sale",
          createdAt: new Date().toISOString(),
        }),
      });

      const product = products.find((x) => x._id === item.productId);
      if (product) {
        await fetch("/api/data", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            collection: "products",
            id: product._id,
            stock: Math.max(0, Number(product.stock || 0) - item.qty),
          }),
        });
      }
    }

    if (pay && Number(paid || 0) > 0) {
      await fetch("/api/data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          collection: "transactions",
          type: "IN",
          account: pay,
          amount: Number(paid || 0),
          ref: invoiceNo,
          note: "Sale",
          createdAt: new Date().toISOString(),
        }),
      });
    }

    setDone(saved);
  }

  if (done) {
    return (
      <main className="shell">
        <div className="nav no-print">
          <Link href="/">← Dashboard</Link>
          <button className="btn" onClick={() => print()}>🖨 Print / Save PDF</button>
          <button
            className="btn green"
            onClick={() => {
              const url = location.origin + "/invoice/" + done._id;
              location.href = "https://wa.me/?text=" + encodeURIComponent("New Arif Mobile Center Invoice " + done.invoiceNo + " " + url);
            }}
          >
            WhatsApp
          </button>
          <Link className="btn" href="/pos">New Sale</Link>
        </div>
        <div className="panel receipt">
          <h2 style={{ textAlign: "center" }}>NEW ARIF MOBILE CENTER</h2>
          <div className="line" />
          <b>Invoice:</b> {done.invoiceNo}<br />
          <b>Date:</b> {new Date(done.createdAt).toLocaleString()}<br />
          {done.saleType === "cash" ? (
            <><b>Cash Ref:</b> {done.cashRef}<br /></>
          ) : (
            <><b>Customer:</b> {customers.find((c) => c._id === done.customerId)?.name || "Customer"}<br /></>
          )}
          <b>Pickup By:</b> {done.pickupBy || "Customer"}<br />
          <b>Pickup Mobile:</b> {done.pickupPhone || "-"}
          <div className="line" />
          {done.items.map((item: any) => (
            <div key={item.productId}>{item.name} × {item.qty} — Rs. {item.price * item.qty}</div>
          ))}
          <div className="line" />
          <b>TOTAL: Rs. {done.total}</b><br />
          <b>PAID: Rs. {done.paid}</b><br />
          <b>REMAINING: Rs. {done.remaining}</b><br />
          <b>PAYMENT: {done.paymentMethod}</b>
          <div className="line" />
          <b>Warranty:</b> {done.warrantyDays || 0} days<br />
          <small>Physical/water damage and broken seal are not covered. Receipt required.</small>
        </div>
      </main>
    );
  }

  return (
    <main className="shell">
      <div className="nav">
        <Link href="/">← Dashboard</Link>
        <Link href="/customers">Customers</Link>
        <Link href="/admin">Products</Link>
      </div>
      <h1>🛒 POS / New Sale</h1>
      <div className="panel">
        <div className="grid">
          <div>
            <label>Sale Type / Customer</label>
            <select className="input" value={customer} onChange={(e) => { setCustomer(e.target.value); if (e.target.value) setCashRef(""); }}>
              <option value="">— Cash Sale —</option>
              {customers.map((c) => <option key={c._id} value={c._id}>{c.name} {c.phone || ""}</option>)}
            </select>
          </div>
          <input className="input" value={cashRef} onChange={(e) => { setCashRef(e.target.value); if (e.target.value) setCustomer(""); }} placeholder="Cash Sale Ref (e.g. AHSAN)" />
          <input className="input" value={pickup} onChange={(e) => setPickup(e.target.value)} placeholder="Pickup By (optional)" />
          <input className="input" value={pickupPhone} onChange={(e) => setPickupPhone(e.target.value)} placeholder="Pickup Mobile (optional)" />
          <select className="input" value={pay} onChange={(e) => setPay(e.target.value)}>
            {["Cash", "JazzCash", "Easypaisa", "Raast", "NayaPay", "UBL", "Other Bank"].map((x) => <option key={x}>{x}</option>)}
          </select>
          <input className="input" type="number" value={paid} onChange={(e) => setPaid(e.target.value)} placeholder="Paid Amount" />
          <input className="input" type="number" value={warranty} onChange={(e) => setWarranty(e.target.value)} placeholder="Warranty days" />
          <input className="input" value={imei} onChange={(e) => setImei(e.target.value)} placeholder="IMEI / Serial (optional)" />
        </div>
      </div>

      <div className="panel">
        <input className="input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search product / model / SKU..." />
        <div className="grid">
          {products
            .filter((p) => (p.name + " " + p.model + " " + (p.sku || "")).toLowerCase().includes(search.toLowerCase()) && Number(p.stock) > 0)
            .map((p) => (
              <button className="card" key={p._id} onClick={() => add(p)}>
                <h2>{p.name}</h2>
                <p className="muted">{p.model} • Stock {p.stock}</p>
                <b>Rs. {p.price}</b>
              </button>
            ))}
        </div>
      </div>

      <div className="panel">
        <h2>Cart</h2>
        {items.map((item) => (
          <div className="row" key={item.productId}>
            <div className="col">{item.name} × {item.qty}</div>
            <b>Rs. {item.price * item.qty}</b>
          </div>
        ))}
        <hr />
        <div className="total">Total: Rs. {total}</div>
        <button className="btn green" onClick={complete}>Complete Sale & Invoice</button>
      </div>
    </main>
  );
}
